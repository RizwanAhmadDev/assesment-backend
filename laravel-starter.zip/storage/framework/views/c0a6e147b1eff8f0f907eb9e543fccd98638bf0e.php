<?php $__env->startSection('title'); ?> <?php echo e($module_action); ?> <?php echo e($module_title); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.backend-breadcrumbs','data' => []]); ?>
<?php $component->withName('backend-breadcrumbs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.backend-breadcrumb-item','data' => ['route' => ''.e(route("backend.$module_name.index")).'','icon' => ''.e($module_icon).'']]); ?>
<?php $component->withName('backend-breadcrumb-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['route' => ''.e(route("backend.$module_name.index")).'','icon' => ''.e($module_icon).'']); ?>
        <?php echo e($module_title); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.backend-breadcrumb-item','data' => ['type' => 'active']]); ?>
<?php $component->withName('backend-breadcrumb-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'active']); ?>Profile <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-8">
                <h4 class="card-title mb-0">
                    <i class="<?php echo e($module_icon); ?>"></i> Profile
                    <small class="text-muted"><?php echo e(__('labels.backend.users.show.action')); ?> </small>
                </h4>
                <div class="small text-muted">
                    <?php echo e(__('labels.backend.users.index.sub-title')); ?>

                </div>
            </div>
            <!--/.col-->
            <div class="col-4">
                <div class="float-right">
                    <a href="<?php echo e(route("backend.users.profileEdit", $user->id)); ?>" class="btn btn-primary mt-1 btn-sm" data-toggle="tooltip" title="Edit <?php echo e(Str::singular($module_name)); ?> Profile"><i class="fas fa-wrench"></i> Edit</a>
                </div>
            </div>
            <!--/.col-->
        </div>
        <!--/.row-->

        <div class="row mt-4 mb-4">
            <div class="col">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <tr>
                            <th><?php echo e(__('labels.backend.users.fields.avatar')); ?></th>
                            <td><img src="<?php echo e(asset($user->avatar)); ?>" class="user-profile-image img-fluid img-thumbnail" style="max-height:200px; max-width:200px;" /></td>
                        </tr>

                        <?php $fields_array = [
                            [ 'name' => 'name' ],
                            [ 'name' => 'email' ],
                            [ 'name' => 'mobile' ],
                            [ 'name' => 'gender' ],
                            [ 'name' => 'date_of_birth', 'type' => 'date'],
                            [ 'name' => 'url_website', 'type' => 'url' ],
                            [ 'name' => 'url_facebook', 'type' => 'url' ],
                            [ 'name' => 'url_twitter', 'type' => 'url' ],
                            [ 'name' => 'url_linkedin', 'type' => 'url' ],
                            [ 'name' => 'profile_privecy' ],
                            [ 'name' => 'address' ],
                            [ 'name' => 'bio' ],
                            [ 'name' => 'login_count' ],
                            [ 'name' => 'last_login', 'type' => 'datetime' ],
                            [ 'name' => 'last_ip' ],
                        ]; ?>
                        <?php $__currentLoopData = $fields_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <?php
                                $field_name = $field['name'];
                                $field_type = isset($field['type'])? $field['type'] : '';
                                ?>

                                <th><?php echo e(__("labels.backend.users.fields.".$field_name)); ?></th>

                                <?php if($field_name == 'date_of_birth' && $userprofile->$field_name != ''): ?>
                                <td>
                                    <?php if(auth()->user()->id == $userprofile->user_id): ?>
                                    <?php echo e($userprofile->$field_name->isoFormat('LL')); ?>

                                    <?php else: ?>
                                    <?php echo e($userprofile->$field_name->format('jS \\of F')); ?>

                                    <?php endif; ?>
                                </td>
                                <?php elseif($field_type == 'date' && $userprofile->$field_name != ''): ?>
                                <td>
                                    <?php echo e($userprofile->$field_name->isoFormat('LL')); ?>

                                </td>
                                <?php elseif($field_type == 'datetime' && $userprofile->$field_name != ''): ?>
                                <td>
                                    <?php echo e($userprofile->$field_name->isoFormat('llll')); ?>

                                </td>
                                <?php elseif($field_type == 'url'): ?>
                                <td>
                                    <a href="<?php echo e($userprofile->$field_name); ?>" target="_blank"><?php echo e($userprofile->$field_name); ?></a>
                                </td>
                                <?php else: ?>
                                <td><?php echo e($userprofile->$field_name); ?></td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <th><?php echo e(__('labels.backend.users.fields.password')); ?></th>
                            <td>
                                <a href="<?php echo e(route('backend.users.changeProfilePassword', $user->id)); ?>" class="btn btn-outline-primary btn-sm">Change password</a>
                            </td>
                        </tr>

                        <tr>
                            <th><?php echo e(__('labels.backend.users.fields.social')); ?></th>
                            <td>
                                <ul class="list-unstyled">
                                    <?php $__currentLoopData = $user->providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <i class="fab fa-<?php echo e($provider->provider); ?>"></i> <?php echo e(label_case($provider->provider)); ?>

                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </td>
                        </tr>

                        <tr>
                            <th><?php echo e(__('labels.backend.users.fields.status')); ?></th>
                            <td><?php echo $user->status_label; ?></td>
                        </tr>

                        <tr>
                            <th><?php echo e(__('labels.backend.users.fields.confirmed')); ?></th>
                            <td><?php echo $user->confirmed_label; ?></td>
                        </tr>
                        <tr>
                            <th><?php echo e(__('labels.backend.users.fields.roles')); ?></th>
                            <td>
                                <?php if($user->roles()->count() > 0): ?>
                                    <ul>
                                        <?php $__currentLoopData = $user->roles(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e(ucwords($role)); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                <?php endif; ?>
                            </td>

                        </tr>
                        <tr>
                            <th><?php echo e(__('labels.backend.users.fields.permissions')); ?></th>
                            <td>
                                <?php if($user->permissions()->count() > 0): ?>
                                    <ul>
                                        <?php $__currentLoopData = $user->permissions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($permission['name']); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                <?php endif; ?>
                            </td>
                        </tr>

                        <tr>
                            <th><?php echo e(__('labels.backend.users.fields.created_at')); ?></th>
                            <td><?php echo e($user->created_at->isoFormat('llll')); ?><br><small>(<?php echo e($user->created_at->diffForHumans()); ?>)</small></td>
                        </tr>

                        <tr>
                            <th><?php echo e(__('labels.backend.users.fields.updated_at')); ?></th>
                            <td><?php echo e($user->updated_at->isoFormat('llll')); ?><br/><small>(<?php echo e($user->updated_at->diffForHumans()); ?>)</small></td>
                        </tr>

                    </table>
                </div><!--table-responsive-->
            </div>
            <!--/.col-->
        </div>
        <!--/.row-->
    </div>
    <div class="card-footer">
        <div class="row">
            <div class="col">
                <small class="float-right text-muted">
                    Updated: <?php echo e($user->updated_at->diffForHumans()); ?>,
                    Created at: <?php echo e($user->created_at->isoFormat('LLLL')); ?>

                </small>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/backend/users/profile.blade.php ENDPATH**/ ?>