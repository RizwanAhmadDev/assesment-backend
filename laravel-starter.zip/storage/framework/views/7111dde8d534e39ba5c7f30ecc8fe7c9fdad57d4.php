<div class="preloader bg-soft flex-column justify-content-center align-items-center">
    <div class="loader-element">
        <span class="loader-animated-dot"></span>
        <img src="<?php echo e(asset('img/logo-with-text-dark.png')); ?>" height="40" alt="<?php echo e(app_name()); ?>">
    </div>
</div>
<?php /**PATH /var/www/html/resources/views/components/preloader.blade.php ENDPATH**/ ?>