<?php
$module_icon = "c-icon cil-list-rich";
?>

<?php $__env->startSection('title'); ?> <?php echo e(__('Log Viewer Dashboard')); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.backend-breadcrumbs','data' => []]); ?>
<?php $component->withName('backend-breadcrumbs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.backend-breadcrumb-item','data' => ['route' => ''.e(route('log-viewer::dashboard')).'','icon' => ''.e($module_icon).'']]); ?>
<?php $component->withName('backend-breadcrumb-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['route' => ''.e(route('log-viewer::dashboard')).'','icon' => ''.e($module_icon).'']); ?>
        <?php echo e(__('Log Viewer Dashboard')); ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.backend-breadcrumb-item','data' => ['route' => ''.e(route('log-viewer::logs.list')).'']]); ?>
<?php $component->withName('backend-breadcrumb-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['route' => ''.e(route('log-viewer::logs.list')).'']); ?><?php echo e(__('Logs by Date')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.backend-breadcrumb-item','data' => ['type' => 'active']]); ?>
<?php $component->withName('backend-breadcrumb-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'active']); ?><?php echo app('translator')->get('Log'); ?> [<?php echo e($log->date); ?>] <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-8">
                <h4 class="card-title mb-0">
                    <i class="<?php echo e($module_icon); ?>"></i> <?php echo app('translator')->get('Log'); ?> [<?php echo e($log->date); ?>]
                    <small class="text-muted"> <?php echo app('translator')->get('Details'); ?> </small>
                </h4>
                <div class="small text-muted">
                    <?php echo app('translator')->get('Log Viewer Module'); ?>
                </div>
            </div>

            <div class="col-4">
                <div class="btn-toolbar float-right" role="toolbar" aria-label="Toolbar with button groups">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.buttons.return-back','data' => []]); ?>
<?php $component->withName('buttons.return-back'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </div>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col">

                <div class="row">
                    <div class="col-lg-2">
                        
                        <div class="card mb-4">
                            <div class="card-header"><i class="fa fa-fw fa-flag"></i> <?php echo app('translator')->get('Levels'); ?></div>
                            <div class="list-group list-group-flush log-menu">
                                <?php $__currentLoopData = $log->menu(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $levelKey => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($item['count'] === 0): ?>
                                        <a class="list-group-item list-group-item-action d-flex justify-content-between align-items-center disabled">
                                            <span class="level-name"><?php echo $item['icon']; ?> <?php echo e($item['name']); ?></span>
                                            <span class="badge empty"><?php echo e($item['count']); ?></span>
                                        </a>
                                    <?php else: ?>
                                        <a href="<?php echo e($item['url']); ?>" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center level-<?php echo e($levelKey); ?><?php echo e($level === $levelKey ? ' active' : ''); ?>">
                                            <span class="level-name"><?php echo $item['icon']; ?> <?php echo e($item['name']); ?></span>
                                            <span class="badge badge-level-<?php echo e($levelKey); ?>"><?php echo e($item['count']); ?></span>
                                        </a>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-10">
                        
                        <div class="card mb-4">
                            <div class="card-header">
                                <strong>
                                    <?php echo app('translator')->get('Log Info'); ?>
                                </strong>
                                <div class="btn-toolbar float-right">
                                    <a href="<?php echo e(route('log-viewer::logs.download', [$log->date])); ?>" class="btn btn-success">
                                        <i class="fas fa-download"></i>&nbsp;<?php echo app('translator')->get('Download'); ?>
                                    </a>
                                    <a href="#delete-log-modal" class="btn btn-danger ml-1" data-toggle="modal">
                                        <i class="fas fa-trash-alt"></i>&nbsp;<?php echo app('translator')->get('Delete'); ?>
                                    </a>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-condensed mb-0">
                                    <tbody>
                                        <tr>
                                            <td>File path :</td>
                                            <td colspan="7"><?php echo e($log->getPath()); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Log entries : </td>
                                            <td>
                                                <span class="badge badge-primary"><?php echo e($entries->total()); ?></span>
                                            </td>
                                            <td>Size :</td>
                                            <td>
                                                <span class="badge badge-primary"><?php echo e($log->size()); ?></span>
                                            </td>
                                            <td>Created at :</td>
                                            <td>
                                                <span class="badge badge-primary"><?php echo e($log->createdAt()); ?></span>
                                            </td>
                                            <td>Updated at :</td>
                                            <td>
                                                <span class="badge badge-primary"><?php echo e($log->updatedAt()); ?></span>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="card-footer">
                                
                                <form action="<?php echo e(route('log-viewer::logs.search', [$log->date, $level])); ?>" method="GET">
                                    <div class=form-group">
                                        <div class="input-group">
                                            <input id="query" name="query" class="form-control"  value="<?php echo request('query'); ?>" placeholder="Type here to search">
                                            <div class="input-group-append">
                                                <?php if(request()->has('query')): ?>
                                                    <a href="<?php echo e(route('log-viewer::logs.show', [$log->date])); ?>" class="btn btn-secondary">
                                                        <i class="fa fa-fw fa-times"></i>
                                                    </a>
                                                <?php endif; ?>
                                                <button id="search-btn" class="btn btn-primary">
                                                    <span class="fa fa-fw fa-search"></span>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>

                        
                        <div class="card mb-4">
                            <?php if($entries->hasPages()): ?>
                                <div class="card-header">
                                    <span class="badge badge-info float-right">
                                        Page <?php echo $entries->currentPage(); ?> of <?php echo $entries->lastPage(); ?>

                                    </span>
                                </div>
                            <?php endif; ?>

                            <div class="table-responsive">
                                <table id="entries" class="table mb-0">
                                    <thead>
                                        <tr>
                                            <th>ENV</th>
                                            <th style="width: 120px;">Level</th>
                                            <th style="width: 65px;">Time</th>
                                            <th>Header</th>
                                            <th class="text-right">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td>
                                                    <span class="badge badge-env"><?php echo e($entry->env); ?></span>
                                                </td>
                                                <td>
                                                    <span class="badge badge-level-<?php echo e($entry->level); ?>">
                                                        <?php echo $entry->level(); ?>

                                                    </span>
                                                </td>
                                                <td>
                                                    <span class="badge badge-secondary">
                                                        <?php echo e($entry->datetime->format('H:i:s')); ?>

                                                    </span>
                                                </td>
                                                <td>
                                                    <?php echo e($entry->header); ?>

                                                </td>
                                                <td class="text-right">
                                                    <?php if($entry->hasStack()): ?>
                                                        <a class="btn btn-sm btn-light" role="button" data-toggle="collapse" href="#log-stack-<?php echo e($key); ?>" aria-expanded="false" aria-controls="log-stack-<?php echo e($key); ?>">
                                                            <i class="fa fa-toggle-on"></i> Stack
                                                        </a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                            <?php if($entry->hasStack()): ?>
                                                <tr>
                                                    <td colspan="5" class="stack py-0">
                                                        <div class="stack-content collapse" id="log-stack-<?php echo e($key); ?>">
                                                            <?php echo $entry->stack(); ?>

                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="5" class="text-center">
                                                    <span class="badge badge-secondary"><?php echo e(trans('log-viewer::general.empty-logs')); ?></span>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <?php echo $entries->appends(compact('query'))->render(); ?>

                    </div>
                </div>

            </div>
        </div>
    </div>
</div>




<div id="delete-log-modal" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <form id="delete-log-form" action="<?php echo e(route('log-viewer::logs.delete')); ?>" method="POST">
            <input type="hidden" name="_method" value="DELETE">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <input type="hidden" name="date" value="<?php echo e($log->date); ?>">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">DELETE LOG FILE</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to <span class="badge badge-danger">DELETE</span> this log file <span class="badge badge-primary"><?php echo e($log->date); ?></span> ?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-sm btn-secondary mr-auto" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-sm btn-danger" data-loading-text="Loading&hellip;">DELETE FILE</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>
    <script>
        $(function () {
            var deleteLogModal = $('div#delete-log-modal'),
                deleteLogForm  = $('form#delete-log-form'),
                submitBtn      = deleteLogForm.find('button[type=submit]');

            deleteLogForm.on('submit', function(event) {
                event.preventDefault();
                submitBtn.button('loading');

                $.ajax({
                    url:      $(this).attr('action'),
                    type:     $(this).attr('method'),
                    dataType: 'json',
                    data:     $(this).serialize(),
                    success: function(data) {
                        submitBtn.button('reset');
                        if (data.result === 'success') {
                            deleteLogModal.modal('hide');
                            location.replace("<?php echo e(route('log-viewer::logs.list')); ?>");
                        }
                        else {
                            alert('OOPS ! This is a lack of coffee exception !')
                        }
                    },
                    error: function(xhr, textStatus, errorThrown) {
                        alert('AJAX ERROR ! Check the console !');
                        console.error(errorThrown);
                        submitBtn.button('reset');
                    }
                });

                return false;
            });

            <?php if (! (empty(log_styler()->toHighlight()))): ?>
                <?php
                    $htmlHighlight = version_compare(PHP_VERSION, '7.4.0') >= 0
                        ? join('|', log_styler()->toHighlight())
                        : join(log_styler()->toHighlight(), '|');
                ?>

                $('.stack-content').each(function() {
                    var $this = $(this);
                    var html = $this.html().trim()
                        .replace(/(<?php echo $htmlHighlight; ?>)/gm, '<strong>$1</strong>');

                    $this.html(html);
                });
            <?php endif; ?>
        });
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('after-styles'); ?>
<?php echo $__env->make('log-viewer::laravel-starter.partials.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/vendor/log-viewer/laravel-starter/show.blade.php ENDPATH**/ ?>