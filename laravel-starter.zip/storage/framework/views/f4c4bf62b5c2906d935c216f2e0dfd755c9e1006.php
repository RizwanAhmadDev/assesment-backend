<footer class="c-footer text-muted">
    <div>
        <a href="/"><?php echo e(app_name()); ?></a>
        <?php if(setting('show_copyright')): ?>
        <?php echo app('translator')->get('Copyright'); ?> &copy; <?php echo e(date('Y')); ?>

        <?php endif; ?>
    </div>
    <div class="ml-auto text-muted"><?php echo setting('footer_text'); ?></div>
</footer>
<?php /**PATH /var/www/html/resources/views/backend/includes/footer.blade.php ENDPATH**/ ?>