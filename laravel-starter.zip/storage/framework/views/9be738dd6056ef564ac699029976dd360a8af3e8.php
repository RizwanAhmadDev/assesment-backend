<li class="breadcrumb-item"><a href="<?php echo e(route('backend.dashboard')); ?>"><i class="c-icon cil-speedometer"></i> <?php echo e(__('Dashboard')); ?></a></li>

<?php echo $slot; ?>

<?php /**PATH /var/www/html/resources/views/components/backend-breadcrumbs.blade.php ENDPATH**/ ?>