<?php

return [
    'name' => 'Tag'
];
