@push('after-styles')
<!-- Lightbox2 CSS -->
        <link href="{{ asset('vendor/lightbox2/css/lightbox.min.css') }}" rel="stylesheet">
@endpush

@push('after-scripts')
<!-- Lightbox2 JS -->
        <script src="{{ asset('vendor/lightbox2/js/lightbox.min.js') }}"></script>
@endpush
